


1. 서버 실행이 안 될 경우 조치방법

 - Flask 설치 여부 확인
	pip install flask

 - Python 2.7을 사용하는지 확인


2. 서버 실행방법 : python run.py