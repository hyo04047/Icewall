import pickle, marshal, types
check = types.FunctionType(
            marshal.loads(
                pickle.load(
                    open('check1.lib', 'rb')
                    # 1번 문제는 check1.lib를
                    # 2번 문제는 check2.lib를 로드하면 됩니다.
            )),
            globals(),
            'check'
        )

# Your code here!

check('ICEWALL')
# maybe return false, It's not that easy.